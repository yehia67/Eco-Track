# Changelog

## v1.2.1

* Added Blueprint and GitHub links
* File size limit 0.5Mb

## v1.2.0

* Added sha3 hash algorithm

## v1.1.1

* Increased storage size to 5Mb

## v1.0.0

* Initial Release
