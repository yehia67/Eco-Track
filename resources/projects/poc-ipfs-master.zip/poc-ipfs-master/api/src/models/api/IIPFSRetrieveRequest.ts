export interface IIPFSRetrieveRequest {
    /**
     * The transaction hash of the file to retrieve.
     */
    transactionHash: string;
}
