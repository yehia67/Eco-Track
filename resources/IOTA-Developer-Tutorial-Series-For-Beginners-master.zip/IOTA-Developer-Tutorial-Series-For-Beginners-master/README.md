# IOTA Developer Tutorial Series For Beginners

---------------

For video tutorials please visit : https://www.youtube.com/c/CodeXpert

---------------

Note : This repository is modified version of https://github.com/iotaledger/high-mobility-blueprints/tree/master/charger and is meant only for educational purposes.