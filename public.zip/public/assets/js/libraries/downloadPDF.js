const downloadFile = (filename,content)=>{
    const doc = new jsPDF('landscape')  
    doc.setFontSize(7);    
    doc.text(20, 20,content)
    doc.save(filename+'.pdf')
}


const downloadNFCTags = (nfcsTags) =>{
    let nfcTagsFileContent = "";
    for (let index = 0; index < nfcsTags.length; index++) {
      nfcTagsFileContent += "Product number "+ Number(index+1) +": "+"\r\n" + nfcsTags[index] + "\r\n\r\n" 
    }
    downloadFile('NFC_Tags',nfcTagsFileContent);
  }