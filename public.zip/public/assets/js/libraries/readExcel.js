const getProductsData = async()=>{
    let products = ""
    const product = {} 
   return  new Promise( (resolve,err)=>{var input = document.getElementById('productsFile')
      readXlsxFile(input.files[0]).then(function(rows) {
        for (let row = 1; row < rows.length; row++) {
          for (let col = 0;col < rows[row].length; col++) {
            product[rows[0][col]] = rows[row][col]
          }
        products += JSON.stringify(product) + "/"
      }    
      resolve(products)
      })
    })
       
  }