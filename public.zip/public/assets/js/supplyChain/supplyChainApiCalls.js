const addUserCall = async(user)=>{
    showLoading()
    $.ajax({
      global: false,
      type: 'POST',
      url: '/user/add',   
      dataType: 'json',
      data:user,
      success: function (result) {
          console.log(result);
          goToRoot(result);
      },
      error: function (request, status, error) {
          serviceError();
      }
  });
  }
 
const createProductsCall = (_products)=>{
     $.ajax({
       global: false,
       type: 'POST',
       url: '/products/create',   
       dataType: 'json',
       data:JSON.parse(JSON.stringify(_products)),
       success: function (result) {
           console.log(result);
           hideLoading();
           downloadNFCTags(result);
         },
       error: function (request, status, error) {
           serviceError();
           console.error(error);
       }
   });
}
