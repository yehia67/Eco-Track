
const validation = (validateUser)=>{
    if (validateUser['fname'].length >= 3 && validateUser['lname'].length >= 3 && validateUser['email'].indexOf('@') !== -1 &&  validateUser['bussines_info'].length > 10){
      return true
    }
    $('.alert-danger').css({ 'display': 'block' })
    return false
  }

const goToRoot = (user)=>{
      const userJson = JSON.parse(JSON.stringify(user))
      $('#signUp').css({ 'display': 'none' })
      $('.seed').append(userJson['seed'])
      $('.key').append(userJson['key'])
      $('#seedKey').css({ 'display': 'block' })
      hideLoading()
  
}

  /****User Dashboard ****/
const initDashboard = (user) =>{
  hideLoading()
  $('.user-title').html('Welcome')
  $('.seed').append(user['seed'])
  $('.key').append(user['key'])
  $('.user-info').css({ 'display': ' none' })
  goTo('signIn','seedKey')
}
/*User Dashboard */

const goToDonwloadReports = (user) =>{
   
    goTo('seedKey','downloadReports')
  }
  

const goToSignUp = ()=>{
  goTo("signIn","signUp")
}

const goToDashboard = ()=>{
  goTo('uploadProducts','seedKey')
}

const goToDashboardFromReport = ()=>{
  goTo('downloadReports','seedKey')
}
const goToSignIn = ()=>{
  goTo("signUp","signIn")
}
const goToUploadProducts = ()=>{
    $('#seedKey').css({ 'display': 'none' })
    $('#uploadProducts').css({ 'display': 'block' })
  }

const goTo = (currentID,nextID)=>{
    $('#'+currentID).css({ 'display': 'none' })
    $('#'+nextID).css({ 'display': 'block' })
}  
  
  /**Loading */
  const showLoading = ()=>{
    $('.myloadingImg').css({ 'display': ' inline-block' })
    $('.myloadingText').css({ 'display': ' inline-block' })
  }
  
  const hideLoading = ()=>{
    $('.myloadingImg').css({ 'display': 'none' })
    $('.myloadingText').css({ 'display': ' none' })
  }