/*Add User*/ 
const parseUserData = async()=>{
  const userForm = document.forms.registrationForm
  const userData = new FormData(userForm)
  const userJson = {
    "fname":userData.get('fname'),
    "lname":userData.get('lname'),
    "email":userData.get('email'),
    "bussines_info":userData.get('bussines_info')
  }
  if (validation(userJson)) {
    addUserCall(userJson)
  }
  return userJson
}
/*Add User*/ 

/****Auth User****/ 
const userAuth = async()=>{
  showLoading()
  const userForm = document.forms.signInForm
  const userData = new FormData(userForm)
  const userJson = {
    "seed":userData.get('seed'),
    "key":userData.get('key')
  }
  $.ajax({
    global: false,
    type: 'POST',
    url: '/user/auth',   
    dataType: 'json',
    data:userJson,
    success: function (result) {
        if(result){
          initDashboard(userJson)
        }else{
             alert('401')
        }
    },
    error: function (request, status, error) {
        serviceError();
    }
});
}
/*Auth User*/ 




/****Create Products****/ 

const parseProductsData = async ()=>{ 
  showLoading()
  const products =  await getProductsData();
  const productsForm = document.forms.uploadProductsForm;
  const productsData = new FormData(productsForm);
  const productsJson = {
    "products":products,
    "key":productsData.get('seed'),
    "seedKey":productsData.get('key'),
    "products":products
  }
  createProducts(productsJson);
} 

const createProducts = (_products)=>{
      createProductsCall(_products);
     
}

/****Create Products****/ 
const downloadProducts =()=>{
  showLoading()
  const userForm = document.forms.downloadReportsForm;
  const userData = new FormData(userForm);
  const userJson = {
    "seed":userData.get('seed'),
    "key":userData.get('key'),
    "shippNo":userData.get('shippNo')
  }
  console.log('---------------------------------------------------------------')
  console.log(userJson);
  $.ajax({
    global: false,
    type: 'POST',
    url: '/products/shippement',   
    dataType: 'json',
    data:userJson,
    success: function (result) {
        console.log(result);
        hideLoading();
        downloadNFCTags(result);
      },
    error: function (request, status, error) {
        serviceError();
        console.error(error);
    }
});
 }
