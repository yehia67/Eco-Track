# Eco-Track
Next Generation Blockchain for supply chain and recycling systems

#### Quick demo
```
npm start

```
