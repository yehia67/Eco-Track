const sendData = require('../sendData')
const getSavedData = require('../getSavedData')
const iotaGlobal = require('../IotaGlobal')
const testCases = async ()=>{
//initialize the map
/* const testClientMaps = await  getSavedData.execute(iotaGlobal.address)
const testClientsMapJSON  = JSON.parse(iotaGlobal.lengthModifier(testClientMaps))
testClientsMapJSON['newClinetNo1'] = "NWGHLCCYCBJISRSOYTHGSKTAGZIAYLZWWPANKZXCMKRHBPYMBKOEVWRCKVSVWRT9VYDBUNQJKENXMWIOD"
sendData.execute(iotaGlobal.address,testClientsMapJSON)   */

}
testCases()