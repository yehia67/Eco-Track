package com.example.nfc.mynfcreader.model

class History
